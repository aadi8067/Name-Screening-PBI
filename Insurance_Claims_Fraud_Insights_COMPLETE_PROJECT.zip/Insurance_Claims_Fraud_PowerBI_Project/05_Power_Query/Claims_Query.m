// Create a text parameter named pClaimsCsvPath containing the full path
// to Claims_Cleaned.csv, then paste this query into Advanced Editor.
// Example: C:\Insurance_Claims_Fraud_PowerBI_Project\02_Data\Cleaned\Claims_Cleaned.csv

let
    Source = Csv.Document(
        File.Contents(pClaimsCsvPath),
        [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]
    ),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedTypes = Table.TransformColumnTypes(
        PromotedHeaders,
        {
            {"policy_id", type text},
            {"policy_state", type text},
            {"policy_deductible", Int64.Type},
            {"policy_annual_premium", Currency.Type},
            {"incident_date", type date},
            {"incident_type", type text},
            {"collision_type", type text},
            {"incident_severity", type text},
            {"authorities_contacted", type text},
            {"incident_state", type text},
            {"incident_city", type text},
            {"incident_hour_of_the_day", Int64.Type},
            {"number_of_vehicles_involved", Int64.Type},
            {"bodily_injuries", Int64.Type},
            {"witnesses", Int64.Type},
            {"police_report_available", type text},
            {"claim_amount", Currency.Type},
            {"total_claim_amount", Currency.Type},
            {"fraud_reported", type text}
        },
        "en-US"
    ),
    TrimmedText = Table.TransformColumns(
        ChangedTypes,
        {
            {"policy_id", Text.Trim, type text},
            {"policy_state", Text.Trim, type text},
            {"incident_type", Text.Trim, type text},
            {"incident_severity", Text.Trim, type text},
            {"fraud_reported", Text.Trim, type text}
        }
    ),
    NormalizedFraudLabel = Table.TransformColumns(
        TrimmedText,
        {{"fraud_reported", each Text.Upper(_), type text}}
    ),
    RemovedBlankPolicyIds = Table.SelectRows(
        NormalizedFraudLabel,
        each [policy_id] <> null and [policy_id] <> ""
    )
in
    RemovedBlankPolicyIds
