# Data dictionary — dashboard extract

| Field | Meaning / usage |
|---|---|
| policy_id | Source policy identifier; use as row-level claim reference only if one row is one claim |
| policy_state | State where policy was issued |
| policy_deductible | Policy deductible in USD |
| policy_annual_premium | Annual premium in USD |
| incident_date | Incident date; use as report date |
| incident_type | Incident category |
| collision_type | Collision direction/type |
| incident_severity | Source incident severity category |
| authorities_contacted | Authority contacted |
| incident_state | Incident state |
| incident_city | Incident city |
| incident_hour_of_the_day | Hour of incident (0–23) |
| number_of_vehicles_involved | Vehicles involved |
| bodily_injuries | Reported bodily injuries |
| witnesses | Witness count |
| police_report_available | Police report availability |
| claim_amount | Source claim amount in USD |
| total_claim_amount | Source total claim amount in USD; keep separate from claim_amount |
| fraud_reported | Source fraud label Y/N; not a final adjudication |
