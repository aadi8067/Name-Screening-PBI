# Insurance Claims & Fraud Insights — Power BI Project

## What is included
1. `01_PowerBI_File/Claims_Fraud_Analysis_ORIGINAL_BASELINE.pbix` — your original uploaded PBIX copied byte-for-byte as a safe baseline. It is not falsely presented as the newly redesigned final report.
2. `02_Data/Source/` — original CSV.
3. `02_Data/Cleaned/Claims_Cleaned.csv` — dashboard-ready data with operational fields only.
4. `03_PowerBI_Assets/` — Power BI theme JSON and online icon URLs.
5. `04_DAX/` — DAX measures and Calendar table definition.
6. `05_Power_Query/` — Power Query M query.
7. `06_Design_and_Page_Spec/` — reference image and detailed three-page layout specification.
8. `07_Documentation/` — data profile and this guide.
9. `08_Preview/` — earlier interactive HTML concept preview (not a PBIX).

## Dataset validation
- Rows: 30,000
- Source columns: 24
- Dashboard columns: 19
- Duplicate rows: 0
- Fraud label Y: 3,440
- Fraud label N: 26,560
- Fraud label rate: 11.47%
- Incident date range: 2023-11-09 to 2025-11-08

## Build in Power BI Desktop
1. Open your original PBIX first. Save a working copy under a new name.
2. If it crashes, use the clean CSV as a fresh import: Home > Get Data > Text/CSV > `Claims_Cleaned.csv`.
3. Rename the imported table to `Claims`.
4. Create a parameter `pClaimsCsvPath` with the full local path to the cleaned CSV and optionally use the supplied M query.
5. Import the theme: View > Themes > Browse for themes > `Coastal_Blue_Teal_Theme.json`.
6. Create the measures from `04_DAX/Measures_and_Calendar.dax`. The Calendar section is a calculated table, not a measure.
7. Create relationship `Calendar[Date]` (one) to `Claims[incident_date]` (many), single direction. Mark Calendar as date table.
8. Build the three pages using `06_Design_and_Page_Spec/Report_Page_Specification.md`.
9. Add online icons using the URLs in `03_PowerBI_Assets/Online_Icon_URLs.json` (Image visual > Image URL, or insert image URL where supported).
10. Validate totals and slicer interactions before publishing.

## Important: PBIX vs project assets
A valid `.pbix` is a Power BI Desktop binary that must be saved by Power BI Desktop. This environment cannot run Power BI Desktop or its model engine, so this ZIP does **not** claim to contain a newly compiled or Desktop-validated redesigned PBIX. The included PBIX is the original baseline you supplied. The rest of the bundle contains the complete data, theme, measures, Power Query, icon URLs, design specification and build documentation needed to recreate the report safely in your installed Power BI Desktop.

## Data integrity and responsible interpretation
- This is static historical data, not real-time insurer data.
- `fraud_reported` is the dataset's label. It is not a determination of fraud.
- `claim_amount` and `total_claim_amount` are separate fields; do not add them together without source documentation.
- The source does not contain claim workflow event timestamps, claim status history, handler assignment, payment events or settlement dates. Do not create operational SLA/aging claims from those absent fields.
- Demographic and hobby columns are excluded from the operational dashboard extract to reduce fairness and privacy risk.
- Use only approved, anonymised data for workplace use. This public dataset should not be represented as AXA internal data.
