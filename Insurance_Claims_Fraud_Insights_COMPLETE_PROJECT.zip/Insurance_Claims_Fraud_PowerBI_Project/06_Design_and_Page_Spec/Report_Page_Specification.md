# Report design specification

## Visual design system
- Reference: attached inventory-management dashboard image.
- Canvas: 16:9, 1920 x 1080.
- Background: `#EAF4F6` (pale blue).
- Sidebar: `#1E5263` (deep teal).
- Primary: `#24586B`; secondary teal: `#4D8795`.
- Mint: `#A9D8CE`; warm accent: `#E7B79C`.
- Cards: white, subtle border `#D6E6E9`, rounded corners.
- Typography: Segoe UI.
- Use online Font Awesome SVG icon URLs from `03_PowerBI_Assets/Online_Icon_URLs.json`.
- Suggested layout: 240 px sidebar, 90 px top header, 24 px page gutters.

## Page 1 — Executive Overview
Audience: Claims operations manager.
Top header: `Insurance Claims & Fraud Insights`, subtitle `Motor Claims Operations | Historical Dataset Analysis`.
Slicers: Incident Date, Incident State, Incident Type, Incident Severity.
KPI cards:
1. Total Claims
2. Total Claim Amount
3. Average Claim Amount
4. Fraud-Label Claims
5. Fraud-Label Rate
Charts:
- Line chart: Total Claims by Calendar[Year Month].
- Donut: Claims split by fraud_reported.
- Clustered bar: Total Claims by incident_type.
- Bar: Total Claim Amount by incident_state (Top N 10).
- Small table: Incident severity, Total Claims, Average Claim Amount.

## Page 2 — Incident Analysis
Slicers: Incident Date, State, Incident Type, Severity.
Charts:
- Bar: Total Claims by incident_severity.
- Donut: Total Claims by collision_type.
- Column: Total Claims by incident_hour_of_the_day.
- Bar: Total Claims by number_of_vehicles_involved.
- Matrix: incident_state by incident_type with Total Claims and Total Claim Amount.
- Cards: Total Bodily Injuries, Total Witnesses, Claims with Police Report.
Use aggregated operational categories only. Do not use insured age, sex, education, occupation or hobbies for claim-level decisions.

## Page 3 — Claims Review
Slicers: Incident Date, Incident State, Incident Type, Fraud Label, Severity.
Table columns:
- policy_id
- incident_date
- incident_state
- incident_city
- incident_type
- incident_severity
- claim_amount
- total_claim_amount
- police_report_available
- fraud_reported
Conditional formatting:
- Severity: neutral/amber/red by category.
- fraud_reported: label as `Dataset fraud label`, never `Confirmed Fraud`.
Enable drill-through from Pages 1 and 2 to Claims Review using policy_id and incident_state.

## Page navigation
Use a left-side page navigator with three entries:
- Executive Overview
- Incident Analysis
- Claims Review

## Validation checklist
- Total Claims equals row count after filters are cleared.
- Fraud-Label Claims + Non-Fraud-Label Claims equals Total Claims.
- Fraud-Label Rate is formatted as percentage.
- Calendar is marked as date table and relationship is active.
- Claim Amount and Total Estimated Claim Amount are not added together.
- Every slicer filters all intended visuals.
- Claims Review table responds to slicers and drill-through.
