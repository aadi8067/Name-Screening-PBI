AXA GBS – NAME SCREENING DUMMY DATA
====================================

USE
---
Use 02_Final_Combined_Dummy_CSVs as the input for Power BI prototype development.
The folder contains four separate fact-style CSV files, one per source dataset.

SYNTHETIC DATA NOTICE
--------------------
Every row in the combined datasets is synthetic. The original CSVs are preserved
unchanged in 00_Actual_Reference_Originals for reference only.
Do not use synthetic data for operational, regulatory, customer, or management reporting.

REPORTING WEEKS
---------------
Dummy_Week_1: 19-Oct-2026 to 25-Oct-2026
Dummy_Week_2: 26-Oct-2026 to 01-Nov-2026
Dummy_Week_3: 02-Nov-2026 to 08-Nov-2026
Dummy_Week_4: 09-Nov-2026 to 15-Nov-2026

WEEKLY VARIATION
----------------
Week 1 uses the full reference population. Weeks 2–4 use deterministic samples
of the reference rows to create modest, reproducible volume variation.
Original categorical distributions and source columns are retained.

SYNTHETIC ALERT IDENTIFIERS
---------------------------
Identifiers are prefixed SYNW1-, SYNW2-, SYNW3-, or SYNW4-.
A source alert identifier maps consistently across the four datasets within
the same synthetic week, where it is present in more than one dataset.

ADDED COLUMNS
-------------
ReportingWeekMonday : Monday date for the reporting week.
ReportingAsOfDate   : Sunday date for the weekly snapshot.
DummyWeek           : Dummy week label.
DataType            : DUMMY_SYNTHETIC.

AGING NOTE
----------
Outstanding creation dates are shifted by the same weekly offset as the
reporting snapshot to preserve relative age. The supplied source contains
some creation dates later than 25-Oct-2026; those values are retained and
shifted consistently. Validate this source condition with the business owner
before finalizing aging logic.

IMPORTANT MODELLING NOTE
-----------------------
Outstanding is a weekly snapshot. Use Alert Identifier + ReportingWeekMonday
as its snapshot-level key, not Alert Identifier alone.
The four fact datasets remain separate; do not append all four into one fact table.
