# Insurance Claims & Fraud Insights — Full HD Power BI project

## Project settings
- Canvas: 1920 × 1080 pixels
- Aspect ratio: 16:9
- Design: pale blue, navy and teal, inspired by the supplied dashboard reference.
- Intended Power BI features: native cards, line/bar/donut charts, matrix, table, slicers, page navigation, DAX and Power Query.
- Compatibility approach: standard built-in Power BI visuals and conventional DAX/M; avoid third-party custom visuals and preview-only features.

## Folder contents
- `01_PowerBI_Baseline/Original_User_PBIX_Baseline.pbix`: exact original user PBIX retained as a backup baseline. It is not the newly completed report.
- `02_Data/Original/`: original CSV.
- `02_Data/PowerBI_Ready/Claims.csv`: 30,000-row report-ready extract with 19 operational fields.
- `03_Theme_and_Icons/`: theme JSON and external Font Awesome icon URLs.
- `04_DAX/`: measures and Calendar table definition.
- `05_Power_Query/`: M query using a configurable file path parameter.
- `06_Page_Backgrounds_1920x1080/`: three exact-size Full HD page layout guides.
- `07_Page_Layouts/`: exact visual/page plan and build instructions.
- `08_Documentation/`: dataset profile.

## Build instructions
1. Open Power BI Desktop and create a new blank report (recommended to avoid inherited model/report issues in the old PBIX).
2. Get Data > Text/CSV > select `02_Data/PowerBI_Ready/Claims.csv`; load as table `Claims`.
3. View > Themes > Browse for themes > select `03_Theme_and_Icons/Insurance_Claims_Coastal_Teal_Theme.json`.
4. For each page, set Canvas type to Custom, width 1920 and height 1080. Use the matching PNG layout guide as a page background or as a positioning reference.
5. Create DAX measures and Calendar table from `04_DAX/Measures_and_Calendar.dax`. Create and activate Calendar[Date] -> Claims[incident_date] relationship.
6. Build visuals exactly as specified in `07_Page_Layouts/Report_Layout_and_Build_Steps.md`.
7. Use native page navigator, slicers and native visuals only. The icon URLs are optional decoration; native shapes/icons are more reliable if external URLs are blocked.
8. Save as `Insurance_Claims_Fraud_Insights.pbix`.

## Version compatibility
The package does not depend on a custom visual or preview feature. However, no Power BI file can be guaranteed to work with every future Power BI release. The included original PBIX is only a backup; the new report must be saved by Power BI Desktop to produce a real compiled PBIX. This environment does not have the Power BI Desktop engine, so it cannot honestly claim a newly compiled or Desktop-tested PBIX.
