// Create a text parameter named pClaimsCsvPath.
// Set it to the full path of 02_Data/PowerBI_Ready/Claims.csv.
let
    Source = Csv.Document(
        File.Contents(pClaimsCsvPath),
        [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]
    ),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedTypes = Table.TransformColumnTypes(
        PromotedHeaders,
        {
            {"policy_id", type text}, {"policy_state", type text},
            {"policy_deductible", Int64.Type}, {"policy_annual_premium", Currency.Type},
            {"incident_date", type date}, {"incident_type", type text},
            {"collision_type", type text}, {"incident_severity", type text},
            {"authorities_contacted", type text}, {"incident_state", type text},
            {"incident_city", type text}, {"incident_hour_of_the_day", Int64.Type},
            {"number_of_vehicles_involved", Int64.Type}, {"bodily_injuries", Int64.Type},
            {"witnesses", Int64.Type}, {"police_report_available", type text},
            {"claim_amount", Currency.Type}, {"total_claim_amount", Currency.Type},
            {"fraud_reported", type text}
        }, "en-US"
    )
in
    ChangedTypes
