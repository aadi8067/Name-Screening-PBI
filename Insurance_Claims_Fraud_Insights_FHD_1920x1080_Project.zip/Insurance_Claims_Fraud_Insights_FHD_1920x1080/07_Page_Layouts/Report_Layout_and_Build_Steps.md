# Full HD report layout and implementation guide

## Canvas settings
For each report page, open Format page > Canvas settings:
- Type: Custom
- Width: 1920 px
- Height: 1080 px
- Wallpaper/page background: #EAF4F6
- Display: Fit to page

The three PNG files in `06_Page_Backgrounds_1920x1080` are 1920×1080 visual layout guides based on the requested reference theme. Use them as page backgrounds or as positioning guides. They are not live report visuals; replace/overlay the placeholder panels with native Power BI visuals.

## Page 1 — Executive Overview
Slicers: incident_date, incident_state, incident_type, incident_severity.
Cards: [Total Claims], [Total Claim Amount], [Average Claim Amount], [Fraud-Label Claims], [Fraud-Label Rate].
Line: Calendar[Year Month] by [Total Claims].
Donut: Claims[fraud_reported] by [Total Claims].
Bar: Claims[incident_type] by [Total Claims].
Bar Top N 10: Claims[incident_state] by [Total Claim Amount].

## Page 2 — Incident Analysis
Slicers: incident_date, incident_state, incident_type, incident_severity.
Bar: incident_severity by [Total Claims].
Donut: collision_type by [Total Claims].
Column: incident_hour_of_the_day by [Total Claims].
Bar: number_of_vehicles_involved by [Total Claims].
Matrix: incident_state rows, incident_type columns, [Total Claims] and [Total Claim Amount] values.
Cards: [Severe Claims], [Total Bodily Injuries], [Total Witnesses], [Claims with Police Report].

## Page 3 — Claims Review
Slicers: incident_date, incident_state, incident_type, incident_severity, fraud_reported.
Native Table columns: policy_id, incident_date, incident_state, incident_city, incident_type, incident_severity, claim_amount, total_claim_amount, police_report_available, fraud_reported.
Set fraud field display name to "Dataset Fraud Label". Add drill-through fields policy_id and incident_state if desired.
Use conditional formatting for incident_severity and fraud_reported; do not label a Y value as a confirmed fraud finding.

## Model
Create relationship Calendar[Date] (1) -> Claims[incident_date] (*), single direction. Mark Calendar as the date table. Sort Calendar[Month] by Calendar[Month Number].

## Data quality / scope
- The CSV contains 30,000 historical records.
- `fraud_reported` is an existing dataset label, not an adjudicated fraud outcome.
- `claim_amount` and `total_claim_amount` are distinct fields; do not sum them together.
- There is no claims workflow event history, handler assignment, payment date, or settlement date. Do not claim genuine real-time status, SLA, or ageing metrics.
- Sensitive demographic and hobby attributes are omitted from the report-ready extract.
